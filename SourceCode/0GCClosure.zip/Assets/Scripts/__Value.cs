﻿namespace Closure
{
    public struct __Value
    {
        internal bool _bool;
        internal int _int32;
        internal long _int64;
        internal float _single;
        internal double _double;
        internal string _string;
    }
}
